Aplikasi Sistem Manajemen Travel. Merupakan aplikasi sistem informasi untuk mengelola data perusahaan yang bergerak dalam bidang transportasi. Aplikasi ini ditujukan kepada developer PHP yang ingin belajar tentang CodeIgniter, penggunakan jQuery dan jqGrid, pembuatan function dan stored procedure pada DBMS MySQL, serta bagaimana meng-export data kedalam bentuk excel menggunakan library phpExcel.

Environment

- Webserver Apache 2.x (http://www.apachefriends.org, XAMPP 1.7.x) 
- PHP 5.x (http://www.apachefriends.org, XAMPP 1.7.x)
- MySQL 5.x (http://www.apachefriends.org, XAMPP 1.7.x)

- CodeIgniter 2.1.2 (http://codeigniter.com/)
- jQuery (http://jquery.com/)
- jQueryUI (http://jqueryui.com/)
- jqGrid (http://www.trirand.com/blog/)
- phpExcel (http://phpexcel.codeplex.com/)