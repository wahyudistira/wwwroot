<hgroup>
        <h1 class="site_title"><a href="index.html">C-ITSTAR TRAVEL</a></h1>
        <h2 class="section_title">DASHBOARD</h2>
</hgroup>